#include <stdio.h>

int minDigitChanges (int m, int d) {
    // TO DO
}

int main () {
    int month, day;
    while (scanf("%d", &month) != EOF) {
        scanf( "%d", &day );
        printf( "%d\n", minDigitChanges( month, day ) );
    }
    return 0;
}
 