// Problem ACM002: Return Books
import java.util.Scanner;
public class ACM002 {
   public static void main (String[] args) {
      Scanner in = new Scanner( System.in );
      while (in.hasNext()) {
         String sBorrowDate = in.next();
         String sReturnDate = in.next();
               
         int[] borrowDate = dateFrom( sBorrowDate );
         int[] returnDate = dateFrom( sReturnDate );

         int daysBorrowed = daysPassed( borrowDate, returnDate );
         
         if (daysBorrowed <= 30) {   // [1 .. 30] days
            System.out.println( "The return is successful!" );
         } else { 
            System.out.printf( 
               "You are late, please pay $%.1f!\n",
               lateFee( daysBorrowed - 30 )
            );
         }
      }
      in.close();
   }

   private static double lateFee (int lateDays) {
      // TODO
   }            

   private static int[] dateFrom (String sDate) {
      // TODO
   }
   
   // the d2 day should be equal or after the d1 day
   private static int daysPassed (int[] d1, int[] d2) {
   	// TODO 	  	    
   }
   
   // MORE HELP METHODS
}
