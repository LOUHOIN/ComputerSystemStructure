// Number Transfer
// java NumTransfer i k ddddddddddddd
// @ Max, 2020
public class NumTransfer {   
   public static void main (String[] args) {
      int i = Integer.parseInt( args[0] );
      int k = Integer.parseInt( args[1] );

      long n = digits2Long( args[2], i );
      System.out.println( long2Digits( n, k ) );
   }
  
   public static String DIGITS = 
      "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

   public static long digits2Long (String s, int k) {
      long n = 0L;
      for (int i = 0; i < s.length(); i++)
         n = n * k + DIGITS.indexOf(s.charAt(i));
      return n;
   }

   public static String long2Digits (long n, int k) {
      if (n == 0L) return "0";
      
      String s = "";
      while (n != 0L) {
         int r = (int)(n % k);
         s = DIGITS.charAt(r) + s;
         n = n / k;
      }
      
      return s;
   }
}
