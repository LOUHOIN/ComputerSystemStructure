// Number Transfer
// numtrans i k ddddddddddddd
// @ Max, 2020
#include <stdio.h>
#include <stdlib.h>

int ctoi (char c) {
   if ('0' <= c && c <= '9') return c - '0';
   if ('A' <= c && c <= 'Z') return c - 'A' + 10;
   if ('a' <= c && c <= 'z') return c - 'a' + 10;
   return 0;   
}

long atol_with_radix (char* s, int radix) {
   long n = 0;
   while (*s) {
      n = n * radix + ctoi(*s);
      s++;
   }  
   return n;
}

void main (int argc, char** argv) {
   int i = atoi( argv[1] );
   int k = atoi( argv[2] );
   long n = atol_with_radix( argv[3], i );

   char s[65];   // long has 64 bits 
   ltoa( n, s, k );
   printf( "%s\n", s );
}


