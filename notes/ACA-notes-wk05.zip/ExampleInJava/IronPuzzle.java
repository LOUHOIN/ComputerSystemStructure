/******************************************************************************
 *  Compilation:  javac IronPuzzle.java
 *  Execution:    java IronPuzzle imagename
 *  Dependencies: Picture.java
 *
 *  Data type for manipulating individual pixels of an image. The original
 *  image can be read from a file in jpg, gif, or png format, or the
 *  user can create a blank image of a given dimension. Includes methods for
 *  displaying the image in a window on the screen or saving to a file.
 *
 *  Remarks
 *   - pixel (x, y) is column x and row y, where (0, 0) is upper left
 *
 *  Iron Puzzles
 *  http://nifty.stanford.edu/2011/parlante-image-puzzle/
 *   
 *  The iron-puzzle.png image is a puzzle; it contains an image of something famous,
 *  however the image has been distorted. The famous object is in the red values, 
 *  however the red values have all been divided by 10, so they are too small by a 
 *  factor of 10. The blue and green values are all just meaningless random values
 *  ("noise") added to obscure the real image. You must undo these distortions to 
 *  reveal the real image. First, set all the blue and green values to 0 to get them
 *  out of the way. Look at the result .. if you look very carefully, you may see
 *  the real image, although it is very very dark (way down towards 0). Then multiply
 *  each red value by 10, scaling it back up to approximately its proper value. 
 *  What is the famous object?
 ******************************************************************************/

import java.awt.Color;

public class IronPuzzle {
  public static void main (String[] args) {
    Picture p0 = new Picture( args[0]);
    System.out.printf( "Original image %d-by-%d\n", p0.width(), p0.height());
    p0.show();
    
    System.out.println( "Start to solve..." );
    Picture p1 = new Picture( p0);
    solveIronPuzzle( p1);
    System.out.printf( "Result image %d-by-%d\n", p1.width(), p1.height());
    p1.show();
  }

  public static void solveIronPuzzle (Picture p) {
    for (int x = 0; x < p.width(); x++) {
      for (int y = 0; y < p.height(); y++) {
        Color cPuzzle = p.get( x, y);
        int r = cPuzzle.getRed();
        Color cSolution = new Color( r*10, 0, 0 );  // Color(R,G,B)
        p.set( x, y, cSolution);
      }
    }
  }
}

