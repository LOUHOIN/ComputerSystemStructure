public class PickUpInRange {
   public static int[][] pickUpInRange (int[][] a, int x, int y) {
      int[][] result = new int[a.length][];
      for (int i = 0; i < a.length; i++) {
         int[] temp = new int[ a[i].length ];
         int count = 0;
         for (int n : a[i]) 
            if (x <= n && n <= y) temp[ count++ ] = n;
         int[] row = new int[count];
         System.arraycopy( temp, 0, row, 0, count );
         result[i] = row;
      }
      return result;
   }

   public static void main (String[] args) {
      int[][] b = { {1,-2,0,3}, {2,-4,0,1,8}, {0,0,10,0}, {0,18,0} };
      int[][] a = pickUpInRange( b, 1, 10 );
      for (int[] row : a)
        System.out.println( java.util.Arrays.toString( row ));
   }
}
 
   