// pickup in range
#include <stdlib.h>
#include <stdio.h>

int** pickUp (int* a[], int nRow, int nCola[], int x, int y, int* b[], int* nColb) {
   for (int i = 0; i < nRow; i++) {
      int* temp = (int *) calloc( nCola[i], sizeof(int) );
      int count = 0;
      for (int j = 0; j < nCola[i]; j++) {
         int e = a[i][j];
         if (x <= e && e <= y) 
            *(temp + count++) = e;
      }
      int* row = (int *) calloc( count, sizeof(int) );
      for (int j = 0; j < count; j++) 
         *(row+j) = *(temp+j);
      *(b+i) = row;
      *(nColb+i) = count;
   }
   return b;
}

void printRow (int r[], int len) {
   printf( "[" );
   for (int j = 0; j < len; j++) {
      if (j > 0) printf( ", " );
      printf( "%d", r[j] );
   }
   printf( "]\n" );
}

void print2DArray (int** a, int nRow, int nCol[], char* title) {
   printf( "%s\n", title );
   for (int i = 0; i < nRow; i++)
      printRow( *(a+i), nCol[i] );
}

void main () {
   int r1[4] = {1, -2, 0, 3};
   int r2[5] = {2, -4, 0, 1, 8};
   int r3[4] = {0, 0, 10, 0};
   int r4[3] = {0, 18, 0};
   int* a[] = { r1, r2, r3, r4 };
   int nCola[] = { 4, 5, 4, 3 };
   int* b[4];
   int nColb[4];
   
   print2DArray( a, 4, nCola, "Original 2D Array a:" );
   pickUp( a, 4, nCola, 1, 10, b, nColb );
   print2DArray( b, 4, nColb, "Result 2D Array b:" );
   
   exit( 0 );
}
   